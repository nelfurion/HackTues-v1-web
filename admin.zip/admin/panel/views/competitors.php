<?php
	require_once '../controllers/competitors-controller.php';
?>