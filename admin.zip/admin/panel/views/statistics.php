<?php
	require_once '../controllers/statistics-controller.php';
?>