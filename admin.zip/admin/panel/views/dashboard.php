<?php
	echo '<h1> DASHBOARD </h1>';
	echo '<h3>Последни регистрации</h3>
	<p> Get db rows and sort by date.</p>';
	echo '<h3>Статистика</h3>';
?>