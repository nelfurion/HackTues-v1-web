<input type="button" value="Добави" onclick="addArticle();">
<input type="button" value="Премахни" class="clear">
<?php
	require_once '../controllers/news-controller.php';
?>
