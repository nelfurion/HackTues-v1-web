<?php
	/*require_once '../../../../phpChart_Lite/conf.php';

	$chart = new C_PhpChartX(array(array(11, 9, 5, 12, 14), 'basic_chart'));
	$chart->draw();*/

	$data = [1, 2, 3 ,4 ,5 ,6];
?>